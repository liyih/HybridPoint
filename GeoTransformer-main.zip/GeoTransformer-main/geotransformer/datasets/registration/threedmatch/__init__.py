from geotransformer.datasets.registration.threedmatch.dataset import ThreeDMatchPairDataset
# from geotransformer.datasets.registration.threedmatch.dataset_minkowski import ThreeDMatchPairMinkowskiDataset


__all__ = [
    'ThreeDMatchPairDataset',
    # 'ThreeDMatchPairMinkowskiDataset',
]
