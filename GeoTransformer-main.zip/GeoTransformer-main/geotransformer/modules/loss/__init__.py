from geotransformer.modules.loss.circle_loss import CircleLoss, WeightedCircleLoss

